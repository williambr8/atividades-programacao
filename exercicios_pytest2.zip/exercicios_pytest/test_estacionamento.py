import pytest
from estacionamento import calcular_valor_estacionamento


def test_estacionamento_por_30_minutos():
    # Arrange
    tempo = 30
    valor_esperado = 10

    # Act
    resultado = calcular_valor_estacionamento(tempo)

    # Assert
    assert resultado == valor_esperado


def test_estacionamento_por_60_minutos():
    # Arrange
    tempo = 60
    valor_esperado = 10

    # Act
    resultado = calcular_valor_estacionamento(tempo)

    # Assert
    assert resultado == valor_esperado


def test_estacionamento_por_70_minutos():
    # Arrange
    tempo = 70
    valor_esperado = 15

    # Act
    resultado = calcular_valor_estacionamento(tempo)

    # Assert
    assert resultado == valor_esperado


def test_estacionamento_por_120_minutos():
    # Arrange
    tempo = 120
    valor_esperado = 15

    # Act
    resultado = calcular_valor_estacionamento(tempo)

    # Assert
    assert resultado == valor_esperado


def test_estacionamento_por_121_minutos():
    # Arrange
    tempo = 121
    valor_esperado = 20

    # Act
    resultado = calcular_valor_estacionamento(tempo)

    # Assert
    assert resultado == valor_esperado


def test_estacionamento_por_3_horas():
    # Arrange
    tempo = 180
    valor_esperado = 20

    # Act
    resultado = calcular_valor_estacionamento(tempo)

    # Assert
    assert resultado == valor_esperado


def test_estacionamento_por_24_horas():
    # Arrange
    tempo = 1440
    valor_esperado = 50

    # Act
    resultado = calcular_valor_estacionamento(tempo)

    # Assert
    assert resultado == valor_esperado


def test_estacionamento_acima_de_24_horas():
    # Arrange
    tempo = 2000
    valor_esperado = 50

    # Act
    resultado = calcular_valor_estacionamento(tempo)

    # Assert
    assert resultado == valor_esperado


def test_tempo_zero_deve_lancar_excecao():
    # Arrange
    tempo = 0

    # Act e Assert
    with pytest.raises(ValueError):
        calcular_valor_estacionamento(tempo)


def test_tempo_negativo_deve_lancar_excecao():
    # Arrange
    tempo = -30

    # Act e Assert
    with pytest.raises(ValueError):
        calcular_valor_estacionamento(tempo)