import pytest
from temperatura import (
    celsius_para_fahrenheit,
    fahrenheit_para_celsius
)


def test_zero_celsius_para_fahrenheit():
    # Arrange
    celsius = 0
    valor_esperado = 32

    # Act
    resultado = celsius_para_fahrenheit(celsius)

    # Assert
    assert resultado == valor_esperado


def test_cem_celsius_para_fahrenheit():
    # Arrange
    celsius = 100
    valor_esperado = 212

    # Act
    resultado = celsius_para_fahrenheit(celsius)

    # Assert
    assert resultado == valor_esperado


def test_trinta_e_dois_fahrenheit_para_celsius():
    # Arrange
    fahrenheit = 32
    valor_esperado = 0

    # Act
    resultado = fahrenheit_para_celsius(fahrenheit)

    # Assert
    assert resultado == valor_esperado


def test_duzentos_e_doze_fahrenheit_para_celsius():
    # Arrange
    fahrenheit = 212
    valor_esperado = 100

    # Act
    resultado = fahrenheit_para_celsius(fahrenheit)

    # Assert
    assert resultado == valor_esperado


def test_celsius_para_fahrenheit_com_decimal():
    # Arrange
    celsius = 25
    valor_esperado = 77

    # Act
    resultado = celsius_para_fahrenheit(celsius)

    # Assert
    assert resultado == valor_esperado


def test_fahrenheit_para_celsius_com_decimal():
    # Arrange
    fahrenheit = 98.6
    valor_esperado = 37.0

    # Act
    resultado = fahrenheit_para_celsius(fahrenheit)

    # Assert
    assert resultado == valor_esperado


def test_celsius_com_entrada_nao_numerica():
    # Arrange
    celsius = "zero"

    # Act e Assert
    with pytest.raises(TypeError):
        celsius_para_fahrenheit(celsius)


def test_fahrenheit_com_entrada_nao_numerica():
    # Arrange
    fahrenheit = "trinta e dois"

    # Act e Assert
    with pytest.raises(TypeError):
        fahrenheit_para_celsius(fahrenheit)