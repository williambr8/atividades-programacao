import pytest
from desconto import calcular_desconto


def test_desconto_de_10_porcento():
    # Arrange
    valor_original = 100
    percentual_desconto = 10
    valor_esperado = 90

    # Act
    resultado = calcular_desconto(valor_original, percentual_desconto)

    # Assert
    assert resultado == valor_esperado


def test_desconto_de_50_porcento():
    # Arrange
    valor_original = 200
    percentual_desconto = 50
    valor_esperado = 100

    # Act
    resultado = calcular_desconto(valor_original, percentual_desconto)

    # Assert
    assert resultado == valor_esperado


def test_desconto_de_100_porcento():
    # Arrange
    valor_original = 150
    percentual_desconto = 100
    valor_esperado = 0

    # Act
    resultado = calcular_desconto(valor_original, percentual_desconto)

    # Assert
    assert resultado == valor_esperado


def test_desconto_maior_que_valor_original():
    # Arrange
    valor_original = 50
    percentual_desconto = 100
    valor_esperado = 0

    # Act
    resultado = calcular_desconto(valor_original, percentual_desconto)

    # Assert
    assert resultado == valor_esperado


def test_desconto_maior_que_100_deve_lancar_excecao():
    # Arrange
    valor_original = 100
    percentual_desconto = 101

    # Act e Assert
    with pytest.raises(ValueError):
        calcular_desconto(valor_original, percentual_desconto)


def test_desconto_menor_que_zero_deve_lancar_excecao():
    # Arrange
    valor_original = 100
    percentual_desconto = -10

    # Act e Assert
    with pytest.raises(ValueError):
        calcular_desconto(valor_original, percentual_desconto)